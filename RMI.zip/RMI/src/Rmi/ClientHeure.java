package Rmi;

import java.rmi.Naming;
import java.util.Map;
import java.util.Scanner;

public class ClientHeure {
    public static void main(String[] args) {
        try {
            HeureService stub = (HeureService) Naming.lookup("rmi://localhost:1099/HeureService");

            System.out.println("🌍 Liste des pays disponibles :");
            Map<String, String> paysFuseaux = stub.getListeFuseaux();
            for (String pays : paysFuseaux.keySet()) {
                System.out.println("- " + pays);
            }

            Scanner scanner = new Scanner(System.in);
            System.out.print("\nEntrez le nom d'un pays : ");
            String pays = scanner.nextLine();

            String heure = stub.getHeure(pays);
            System.out.println(heure);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

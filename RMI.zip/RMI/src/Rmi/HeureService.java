package Rmi;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Map;

public interface HeureService extends Remote {
	    String getHeure(String pays) throws RemoteException;
	    Map<String, String> getListeFuseaux() throws RemoteException;
	}

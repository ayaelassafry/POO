package Rmi;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;


public class HeureServiceImpl extends UnicastRemoteObject implements HeureService {
	    private static final Map<String, String> PAYS_FUSEAUX = new HashMap<>();

	    static {
	        PAYS_FUSEAUX.put("France", "Europe/Paris");
	        PAYS_FUSEAUX.put("Maroc", "Africa/Casablanca");
	        PAYS_FUSEAUX.put("États-Unis", "America/New_York");
	        PAYS_FUSEAUX.put("Japon", "Asia/Tokyo");
	        PAYS_FUSEAUX.put("Brésil", "America/Sao_Paulo");
	        PAYS_FUSEAUX.put("Inde", "Asia/Kolkata");
	        PAYS_FUSEAUX.put("Chine", "Asia/Shanghai");
	        PAYS_FUSEAUX.put("Canada", "America/Toronto");
	    }

	    public HeureServiceImpl() throws RemoteException {
	        super();
	    }

	    @Override
	    public String getHeure(String pays) throws RemoteException {
	        String fuseau = PAYS_FUSEAUX.get(pays);
	        if (fuseau == null) {
	            return "Fuseau horaire inconnu pour " + pays;
	        }

	        TimeZone tz = TimeZone.getTimeZone(fuseau);
	        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	        sdf.setTimeZone(tz);
	        return "L'heure actuelle à " + pays + " est : " + sdf.format(new Date());
	    }

	    @Override
	    public Map<String, String> getListeFuseaux() throws RemoteException {
	        return PAYS_FUSEAUX;
	    }
	}





/**
 * 
 */
/**
 * 
 */

	module RMI extends Rmi{
	    exports Rmi;
	    requires java.rmi;
	}

package ReserverHotel;

public class Chambre {
	private int numero;
	private String type ;
	private double prixParNuit;
	public Chambre(int numero, String type ,double prixParNuit) {
		this.numero=numero;
		this.type=type;
		this.prixParNuit=prixParNuit;
		}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getPrixParNuit() {
		return prixParNuit;
	}
	public void setPrixParNuit(double prixParNuit) {
		this.prixParNuit = prixParNuit;
	}
}

package ReserverHotel;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class G_Hotel {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        Chambre chambre1 = new Chambre(200, "Suite", 90.0);
	        Chambre chambre2 = new Chambre(149, "Double", 65.0);
	        List<Chambre> chambres = List.of(chambre1, chambre2);

	        Hotel hotel = new Hotel(chambres);

	        while (true) {
	            System.out.println("\nMenu :");
	            System.out.println("1. Ajouter une réservation");
	            System.out.println("2. Afficher les réservations");
	            System.out.println("3. Vérifier la disponibilité d’une chambre");
	            System.out.println("4. Annuler une réservation");
	            System.out.println("5. Quitter");
	            System.out.print("Votre choix : ");
	            
	            int choix;
	            try {
	                choix = scanner.nextInt();
	            } catch (Exception e) {
	                System.out.println("Veuillez entrer un nombre valide.");
	                scanner.nextLine();
	                continue;
	            }

	            if (choix == 5) break;

	            switch (choix) {
	                case 1:
	                    try {
	                        System.out.print("Nom du client : ");
	                        scanner.nextLine();
	                        String nomClient = scanner.nextLine();
	                        System.out.print("Email du client : ");
	                        String emailClient = scanner.nextLine();
	                        Client client = new Client(nomClient, emailClient);

	                        System.out.print("Numéro de chambre : ");
	                        int numeroChambre = scanner.nextInt();
	                        Chambre chambre = null;
	                        for (Chambre ch : chambres) {
	                            if (ch.getNumero() == numeroChambre) {
	                                chambre = ch;
	                                break;
	                            }
	                        }

	                        if (chambre == null) {
	                            System.out.println("Chambre invalide.");
	                            break;
	                        }

	                        System.out.print("Date d'arrivée (AAAA-MM-JJ) : ");
	                        LocalDate dateArrivee = LocalDate.parse(scanner.next());

	                        System.out.print("Date de départ (AAAA-MM-JJ) : ");
	                        LocalDate dateDepart = LocalDate.parse(scanner.next());

	                        if (!dateDepart.isAfter(dateArrivee)) {
	                            System.out.println("Erreur : la date de départ doit être après la date d'arrivée.");
	                            break;
	                        }

	                        if (hotel.estChambreDisponible(chambre, dateArrivee, dateDepart)) {
	                            hotel.ajouterReservation(new Reservation(client, chambre, dateArrivee, dateDepart));
	                            System.out.println("Réservation ajoutée avec succès !");
	                        } else {
	                            System.out.println("Désolé, la chambre n'est pas disponible pour ces dates.");
	                        }
	                    } catch (Exception e) {
	                        System.out.println("Erreur lors de la réservation. Vérifiez votre saisie.");
	                        scanner.nextLine();
	                    }
	                    break;

	                case 2:
	                    hotel.afficherReservations();
	                    break;

	                case 3:
	                    try {
	                        System.out.print("Numéro de chambre : ");
	                        int numChambre = scanner.nextInt();
	                        System.out.print("Date d'arrivée (AAAA-MM-JJ) : ");
	                        LocalDate dateArrivee = LocalDate.parse(scanner.next());
	                        System.out.print("Date de départ (AAAA-MM-JJ) : ");
	                        LocalDate dateDepart = LocalDate.parse(scanner.next());

	                        Chambre chambreRecherchee = null;
	                        for (Chambre ch : chambres) {
	                            if (ch.getNumero() == numChambre) {
	                                chambreRecherchee = ch;
	                                break;
	                            }
	                        }

	                        if (chambreRecherchee == null) {
	                            System.out.println("Cette chambre n'existe pas.");
	                        } else {
	                            boolean disponible = hotel.estChambreDisponible(chambreRecherchee, dateArrivee, dateDepart);
	                            System.out.println(disponible ? "La chambre est disponible." : "La chambre est occupée.");
	                        }
	                    } catch (Exception e) {
	                        System.out.println("Erreur de saisie. Veuillez entrer des informations valides.");
	                        scanner.nextLine();
	                    }
	                    break;

	                case 4:
	                    try {
	                        System.out.print("Entrez le numéro de chambre à annuler : ");
	                        int numeroChambreAnnulation = scanner.nextInt();
	                        hotel.annulerReservation(numeroChambreAnnulation);
	                    } catch (Exception e) {
	                        System.out.println("Erreur : veuillez entrer un numéro valide.");
	                        scanner.nextLine();
	                    }
	                    break;

	                default:
	                    System.out.println("Option invalide. Veuillez choisir une option entre 1 et 5.");
	            }
	        }

	        System.out.println("Merci d'avoir utilisé notre système de gestion d'hôtel. À bientôt !");
	        scanner.close();
	    }
	}

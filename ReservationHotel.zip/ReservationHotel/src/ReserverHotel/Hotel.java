package ReserverHotel;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Hotel {
	    private List<Chambre> chambres;
	    private List<Reservation> reservations;

	    public Hotel(List<Chambre> chambres) {
	        this.chambres = new ArrayList<>(chambres);
	        this.reservations = new ArrayList<>();
	    }

	    public boolean estChambreDisponible(Chambre chambre, LocalDate dateArrivee, LocalDate dateDepart) {
	        for (Reservation reservation : reservations) {
	            if (reservation.getChambre().equals(chambre)) {
	                LocalDate dateReservArrivee = reservation.getDateArrivee();
	                LocalDate dateReservDepart = reservation.getDateDepart();
	                if (dateArrivee.isBefore(dateReservDepart) && dateDepart.isAfter(dateReservArrivee)) {
	                    return false;
	                }
	            }
	        }
	        return true;
	    }

	    public void ajouterReservation(Reservation reservation) {
	        reservations.add(reservation);
	    }

	    public void afficherReservations() {
	        if (reservations.isEmpty()) {
	            System.out.println("Aucune réservation.");
	        } else {
	            for (Reservation res : reservations) {
	                res.afficherDetailsReservation();
	                System.out.println("--------------------------");
	            }
	        }
	    }

	    public void notifierReservation(int joursAvant) {
	        LocalDate aujourdHui = LocalDate.now();
	        for (Reservation res : reservations) {
	            if (res.getDateArrivee().minusDays(joursAvant).isEqual(aujourdHui)) {
	                System.out.println("Rappel : La réservation pour la chambre " + res.getChambre().getNumero() +
	                        " commence dans " + joursAvant + " jours.");
	            }
	        }
	    }

	    public void annulerReservation(int numeroChambre) {
	        Reservation reservationASupprimer = null;
	        for (Reservation res : reservations) {
	            if (res.getChambre().getNumero() == numeroChambre) {
	                reservationASupprimer = res;
	                break;
	            }
	        }
	        if (reservationASupprimer != null) {
	            reservations.remove(reservationASupprimer);
	            System.out.println("Réservation pour la chambre " + numeroChambre + " annulée.");
	        } else {
	            System.out.println("Aucune réservation trouvée pour la chambre " + numeroChambre + ".");
	        }
	    }

	    public List<Reservation> getReservations() {
	        return new ArrayList<>(reservations);
	    }
	}

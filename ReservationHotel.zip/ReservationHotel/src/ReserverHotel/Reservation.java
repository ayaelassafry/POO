package ReserverHotel;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class Reservation {
	private Client client;
	private Chambre chambre;
	private LocalDate dateArrivee;
	private LocalDate dateDepart;
	private ZonedDateTime heureReservation;
	public Reservation(Client client, Chambre chambre, LocalDate dateArrivee,LocalDate dateDepart) {
		this.client=client;
		this.chambre=chambre;
		this.dateArrivee=dateArrivee;
		this.dateDepart=dateDepart;
		this.heureReservation = ZonedDateTime.now(ZoneId.of("Europe/Paris"));
		
	}
	public Client getClient() {
		return client;
	}
	public void setClient(Client client) {
		this.client = client;
	}
	public Chambre getChambre() {
		return chambre;
	}
	public void setChambre(Chambre chambre) {
		this.chambre = chambre;
	}
	public LocalDate getDateArrivee() {
		return dateArrivee;
	}
	public void setDateArrivee(LocalDate dateArrivee) {
		this.dateArrivee = dateArrivee;
	}
	public LocalDate getDateDepart() {
		return dateDepart;
	}
	public void setDateDepart(LocalDate dateDepart) {
		this.dateDepart = dateDepart;
	}
	public int calculerDureeSejour() {
		return Period.between(dateArrivee, dateDepart).getDays();
	}
	public void afficherDetailsReservation(){
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		System.out.println("Client: " + client.getNom() + " (" + client.getEmail() + ")");
        System.out.println("Chambre: " + chambre.getNumero() + " - " + chambre.getType() + " - Prix/Nuit: " + chambre.getPrixParNuit() + "DH");
        System.out.println("Arrivée: " + dateArrivee.format(formatter) + " | Départ: " + dateDepart.format(formatter));
        System.out.println("Durée du séjour: " + calculerDureeSejour() + " jour");
		
	}
}
